<!-- Hero Section  -->
  <section id="hero">
    <div class="container text-center">
      <div>
        <h1 style="padding-bottom:10px; border-bottom: 2px solid rgb(220, 20, 60)" >SIPENTAS <span></span></h1>
        <h1 style="padding-top:10px; font-size:20px !important;">SISTEM INFORMASI PEMBERIAN TANDA TANGAN TRANSCRIPT<span></span></h1>
        <h1><span></span></h1>
      </div>
    </div>
  </section>
  <!-- End Hero Section  -->
